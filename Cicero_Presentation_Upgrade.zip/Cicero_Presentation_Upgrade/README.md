# Cicero Presentation Studio – module tích hợp

## Có trong bản này
- Khu vực trình chiếu ảnh/slide ở phía trên/trái.
- Camera với thanh zoom khung hình 0.4x–2.0x và các mức nhanh.
- Bật/tắt camera, chế độ toàn màn hình.
- Bộ đếm thời gian; hết giờ tự dừng phiên, dừng phiên âm và tắt camera.
- Phiên âm tiếng Việt bằng Web Speech API nếu trình duyệt hỗ trợ.
- Đọc phiên âm bằng Speech Synthesis.
- Chế độ hỗ trợ tiếp cận với chữ lớn và đọc nội dung mô tả.

## Cài vào dự án React hiện tại
1. Chép `PresentationStudio.jsx` và `PresentationStudio.css` vào `src/components/`.
2. Import component ở trang luyện tập cần dùng:

```jsx
import PresentationStudio from "../components/PresentationStudio";

export default function Practice() {
  return (
    <PresentationStudio
      durationMinutes={3}
      onComplete={(result) => {
        // TODO: gọi hàm đánh giá hiện tại hoặc điều hướng tới trang Evaluation.
        console.log("Kết quả phiên luyện tập:", result);
      }}
    />
  );
}
```

3. Thay `durationMinutes={3}` bằng thời lượng bài luyện tập mà Cicero đang chọn.
4. Kết nối `onComplete` với logic đánh giá hiện có. Module này không tự chấm điểm AI.

## Lưu ý quan trọng
- Đây là component bổ sung độc lập, không phải bản sửa trực tiếp toàn bộ website hiện tại vì chưa có mã nguồn React gốc trong cuộc trò chuyện.
- Zoom 0.4x/0.5x ở đây là zoom khung hình bằng CSS (hiển thị rộng hơn bằng cách thu nhỏ video trong khung sẽ tạo viền trống nếu không đổi object-fit); không thể tạo góc nhìn siêu rộng thật nếu cảm biến/camera không hỗ trợ. Để có góc rộng thật cần camera hỗ trợ lens/facing mode hoặc API zoom phần cứng.
- Web Speech API không được hỗ trợ đồng đều trên mọi trình duyệt; kiểm tra trên Chrome/Edge. Trình duyệt có thể gửi âm thanh đến dịch vụ nhận dạng của nhà cung cấp.
- Camera cần HTTPS hoặc localhost và người dùng phải cấp quyền.
- Hỗ trợ người khiếm thị cần mô tả alt/text cho từng slide. File ảnh đơn lẻ không thể tự được mô tả chính xác nếu không có dịch vụ AI thị giác.
- Phiên âm và Text-to-Speech không phải dịch ngôn ngữ. Module hiện nhận dạng tiếng Việt (`vi-VN`).
- Khi hết giờ, component gọi `onComplete` và tắt camera. M cần nối callback với trang đánh giá sẵn có của Cicero.
