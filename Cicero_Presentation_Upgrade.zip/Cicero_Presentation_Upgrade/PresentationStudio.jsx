import React, { useCallback, useEffect, useRef, useState } from "react";
import "./PresentationStudio.css";

/**
 * Cicero presentation practice module.
 *
 * Integration:
 *   <PresentationStudio
 *     durationMinutes={3}
 *     onComplete={(result) => console.log(result)}
 *   />
 *
 * This is an additive component. It does not replace your existing pages,
 * navigation, theme, or evaluation logic. Connect onComplete to your existing
 * evaluation page/route when integrating it into the current Cicero app.
 */
export default function PresentationStudio({
  durationMinutes = 3,
  onComplete,
  onExit,
}) {
  const [secondsLeft, setSecondsLeft] = useState(
    Math.max(1, Math.round(durationMinutes * 60))
  );
  const [running, setRunning] = useState(false);
  const [finished, setFinished] = useState(false);
  const [zoom, setZoom] = useState(1);
  const [cameraError, setCameraError] = useState("");
  const [cameraOn, setCameraOn] = useState(false);
  const [transcript, setTranscript] = useState("");
  const [speechSupported, setSpeechSupported] = useState(false);
  const [listening, setListening] = useState(false);
  const [accessibilityMode, setAccessibilityMode] = useState(false);
  const [slideUrl, setSlideUrl] = useState("");
  const [slideName, setSlideName] = useState("");
  const videoRef = useRef(null);
  const streamRef = useRef(null);
  const recognitionRef = useRef(null);
  const completedRef = useRef(false);
  const stageRef = useRef(null);
  const startedAtRef = useRef(null);

  const stopCamera = useCallback(() => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((track) => track.stop());
      streamRef.current = null;
    }
    if (videoRef.current) videoRef.current.srcObject = null;
    setCameraOn(false);
  }, []);

  const stopTranscription = useCallback(() => {
    try {
      recognitionRef.current?.stop();
    } catch {
      // Recognition may already be stopped.
    }
    setListening(false);
  }, []);

  const finishSession = useCallback((reason = "time") => {
    if (completedRef.current) return;
    completedRef.current = true;
    setRunning(false);
    setFinished(true);
    stopTranscription();
    stopCamera();
    const elapsedSeconds = startedAtRef.current
      ? Math.max(0, Math.round((Date.now() - startedAtRef.current) / 1000))
      : 0;
    onComplete?.({
      reason,
      elapsedSeconds,
      transcript,
      completedAt: new Date().toISOString(),
    });
  }, [onComplete, stopCamera, stopTranscription, transcript]);

  useEffect(() => {
    if (!running || finished) return undefined;
    const timer = window.setInterval(() => {
      setSecondsLeft((current) => {
        if (current <= 1) {
          window.clearInterval(timer);
          finishSession("time");
          return 0;
        }
        return current - 1;
      });
    }, 1000);
    return () => window.clearInterval(timer);
  }, [running, finished, finishSession]);

  useEffect(() => {
    const SpeechRecognition =
      window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SpeechRecognition) return;
    setSpeechSupported(true);
    const recognition = new SpeechRecognition();
    recognition.lang = "vi-VN";
    recognition.continuous = true;
    recognition.interimResults = true;
    recognition.onresult = (event) => {
      let finalText = "";
      let interimText = "";
      for (let i = event.resultIndex; i < event.results.length; i += 1) {
        const text = event.results[i][0].transcript;
        if (event.results[i].isFinal) finalText += text + " ";
        else interimText += text;
      }
      if (finalText) setTranscript((previous) => (previous + finalText).trimStart());
      // Interim text is intentionally not persisted; final transcript is stable.
      void interimText;
    };
    recognition.onerror = () => setListening(false);
    recognition.onend = () => setListening(false);
    recognitionRef.current = recognition;
    return () => {
      try { recognition.stop(); } catch { /* no-op */ }
    };
  }, []);

  useEffect(() => () => {
    stopTranscription();
    stopCamera();
    if (slideUrl) URL.revokeObjectURL(slideUrl);
  }, [stopCamera, stopTranscription, slideUrl]);

  const startCamera = async () => {
    setCameraError("");
    if (!navigator.mediaDevices?.getUserMedia) {
      setCameraError("Trình duyệt không hỗ trợ camera hoặc trang chưa chạy bằng HTTPS.");
      return;
    }
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        audio: false,
        video: { facingMode: "user", width: { ideal: 1920 }, height: { ideal: 1080 } },
      });
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        await videoRef.current.play();
      }
      setCameraOn(true);
    } catch (error) {
      setCameraError(
        error?.name === "NotAllowedError"
          ? "Bạn chưa cấp quyền camera. Hãy cho phép Camera trong trình duyệt."
          : "Không thể mở camera. Hãy kiểm tra thiết bị hoặc quyền truy cập."
      );
    }
  };

  const startSession = async () => {
    if (finished) return;
    completedRef.current = false;
    startedAtRef.current = Date.now();
    setRunning(true);
    if (!cameraOn) await startCamera();
    if (speechSupported && recognitionRef.current) {
      try {
        recognitionRef.current.start();
        setListening(true);
      } catch {
        // User can still present; transcript may be unavailable.
      }
    }
  };

  const toggleListening = () => {
    if (!speechSupported || !recognitionRef.current) return;
    if (listening) {
      stopTranscription();
      return;
    }
    try {
      recognitionRef.current.start();
      setListening(true);
    } catch {
      setListening(false);
    }
  };

  const toggleFullscreen = async () => {
    try {
      if (!document.fullscreenElement) await stageRef.current?.requestFullscreen?.();
      else await document.exitFullscreen?.();
    } catch {
      // Fullscreen can be blocked by browser/device policy.
    }
  };

  const readAloud = (text) => {
    if (!("speechSynthesis" in window) || !text.trim()) return;
    window.speechSynthesis.cancel();
    window.speechSynthesis.speak(new SpeechSynthesisUtterance(text));
  };

  const handleSlide = (event) => {
    const file = event.target.files?.[0];
    if (!file) return;
    if (slideUrl) URL.revokeObjectURL(slideUrl);
    setSlideUrl(URL.createObjectURL(file));
    setSlideName(file.name);
  };

  const resetSession = () => {
    stopTranscription();
    stopCamera();
    completedRef.current = false;
    setSecondsLeft(Math.max(1, Math.round(durationMinutes * 60)));
    setRunning(false);
    setFinished(false);
    setTranscript("");
    startedAtRef.current = null;
  };

  const formatTime = (total) =>
    `${String(Math.floor(total / 60)).padStart(2, "0")}:${String(total % 60).padStart(2, "0")}`;

  return (
    <main className={`cicero-studio ${accessibilityMode ? "cicero-accessible" : ""}`} ref={stageRef}>
      <header className="cicero-studio__toolbar">
        <div>
          <strong>Cicero · Phòng luyện thuyết trình</strong>
          <span className="cicero-studio__sub">Chế độ luyện tập mở rộng</span>
        </div>
        <div className="cicero-studio__toolbar-actions">
          <button type="button" onClick={() => setAccessibilityMode((v) => !v)}>
            {accessibilityMode ? "Tắt hỗ trợ tiếp cận" : "Hỗ trợ tiếp cận"}
          </button>
          <button type="button" onClick={toggleFullscreen}>Toàn màn hình</button>
          {onExit && <button type="button" onClick={onExit}>Thoát</button>}
        </div>
      </header>

      <section className="cicero-studio__workspace">
        <section className="cicero-studio__presentation" aria-label="Khu vực trình chiếu">
          <div className="cicero-studio__section-heading">
            <h1>Nội dung trình chiếu</h1>
            <label className="cicero-studio__upload">
              Chọn hình ảnh / slide
              <input type="file" accept="image/*" onChange={handleSlide} />
            </label>
          </div>
          <div className="cicero-studio__slide">
            {slideUrl ? (
              <img src={slideUrl} alt={`Slide trình chiếu: ${slideName}`} />
            ) : (
              <div className="cicero-studio__empty-slide">
                <span aria-hidden="true">▧</span>
                <p>Chọn hình ảnh hoặc slide để hiển thị tại đây</p>
              </div>
            )}
          </div>
          {accessibilityMode && (
            <div className="cicero-studio__accessible-tools">
              <button type="button" onClick={() => readAloud(slideName || "Khu vực trình chiếu. Chưa có hình ảnh được chọn.")}>
                Đọc mô tả khu vực trình chiếu
              </button>
              <p>Để hỗ trợ người khiếm thị đầy đủ, hãy bổ sung mô tả văn bản cho từng slide trước khi trình chiếu.</p>
            </div>
          )}
        </section>

        <aside className="cicero-studio__camera-panel" aria-label="Camera người thuyết trình">
          <div className="cicero-studio__section-heading">
            <h2>Camera</h2>
            <span className={`cicero-studio__camera-status ${cameraOn ? "is-on" : ""}`}>
              {cameraOn ? "Đang hoạt động" : "Chưa bật"}
            </span>
          </div>
          <div className="cicero-studio__camera-frame">
            <video ref={videoRef} autoPlay muted playsInline style={{ transform: `scale(${zoom})` }} />
            {!cameraOn && <div className="cicero-studio__camera-placeholder">Camera sẽ hiển thị tại đây</div>}
          </div>
          <div className="cicero-studio__zoom">
            <label htmlFor="camera-zoom">Điều chỉnh khung hình: {zoom.toFixed(1)}x</label>
            <input
              id="camera-zoom"
              type="range"
              min="0.4"
              max="2"
              step="0.1"
              value={zoom}
              onChange={(event) => setZoom(Number(event.target.value))}
            />
            <div className="cicero-studio__zoom-presets">
              {[0.4, 0.5, 0.75, 1, 1.5, 2].map((value) => (
                <button
                  type="button"
                  key={value}
                  className={zoom === value ? "is-selected" : ""}
                  onClick={() => setZoom(value)}
                >
                  {value}x
                </button>
              ))}
            </div>
          </div>
          {cameraError && <p className="cicero-studio__error" role="alert">{cameraError}</p>}
          {!cameraOn ? (
            <button type="button" className="cicero-studio__primary" onClick={startCamera}>Bật camera</button>
          ) : (
            <button type="button" onClick={stopCamera}>Tắt camera</button>
          )}
        </aside>
      </section>

      <section className="cicero-studio__transcript" aria-label="Phiên âm lời nói">
        <div className="cicero-studio__section-heading">
          <div>
            <h2>Phiên âm lời thuyết trình</h2>
            <p>Lời nói được nhận dạng sẽ xuất hiện ở khu vực bên dưới.</p>
          </div>
          <div className="cicero-studio__transcript-actions">
            <span>{listening ? "Đang nghe…" : speechSupported ? "Đã tạm dừng" : "Trình duyệt chưa hỗ trợ nhận dạng giọng nói"}</span>
            {speechSupported && (
              <button type="button" onClick={toggleListening}>{listening ? "Dừng phiên âm" : "Bắt đầu phiên âm"}</button>
            )}
            <button type="button" onClick={() => readAloud(transcript)} disabled={!transcript.trim()}>
              Đọc phiên âm
            </button>
          </div>
        </div>
        <div className="cicero-studio__transcript-body" aria-live="polite">
          {transcript || "Nội dung bạn nói sẽ được hiển thị tại đây…"}
        </div>
      </section>

      <footer className="cicero-studio__footer">
        <div className="cicero-studio__timer" aria-live="off">
          <span>Thời gian còn lại</span>
          <strong className={secondsLeft <= 30 ? "is-warning" : ""}>{formatTime(secondsLeft)}</strong>
        </div>
        <div className="cicero-studio__footer-actions">
          {!running && !finished && (
            <button type="button" className="cicero-studio__primary" onClick={startSession}>
              Bắt đầu thuyết trình
            </button>
          )}
          {running && (
            <button type="button" className="cicero-studio__danger" onClick={() => finishSession("manual")}>
              Kết thúc và đánh giá
            </button>
          )}
          {finished && (
            <>
              <strong className="cicero-studio__finished">Đã kết thúc lượt thuyết trình</strong>
              <button type="button" className="cicero-studio__primary" onClick={() => onComplete?.({
                reason: "continue-to-evaluation",
                elapsedSeconds: Math.max(0, Math.round((Date.now() - (startedAtRef.current || Date.now())) / 1000)),
                transcript,
                completedAt: new Date().toISOString(),
              })}>
                Tiếp tục đánh giá
              </button>
              <button type="button" onClick={resetSession}>Luyện tập lại</button>
            </>
          )}
        </div>
      </footer>
      {finished && (
        <div className="cicero-studio__notice" role="status">
          Đã hết giờ. Camera đã được tắt và phiên thuyết trình đã kết thúc. Bạn có thể chuyển sang đánh giá.
        </div>
      )}
    </main>
  );
}
